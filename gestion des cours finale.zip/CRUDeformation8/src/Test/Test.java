/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Test;

import Entitie.Cour;
import Service.ServiceCour;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;

/**
 *
 * @author user
 */
public class Test {
    static Statement ste;
static ResultSet result;
    public static void main(String[] args) {
        // TODO code application logic here
         ServiceCour ser = new ServiceCour();
        
        Cour C1 = new Cour();
        C1.setTitre("titre");
        
       // C1.setFichier("fichier");
       
       Cour C2 = new Cour();
      
         C2.setTitre("css");
       // C2.setFichier("css2");
       
        List <Cour> list = ser.afficher();
           System.out.println(list);
       
      ser.ajouter(C2);
       
    // ser.modifier(C2);
      //ser.supprimer(C2);
       
       //ser.modifier(C1);
       

       
    
    
    
    
    
    }    
}
