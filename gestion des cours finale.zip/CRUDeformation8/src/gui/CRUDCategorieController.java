/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import Entitie.Catégorie;
import Service.Servicecategorie;
import java.awt.Image;
import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import org.controlsfx.control.Notifications;
import static sun.font.FontManagerNativeLibrary.load;

/**
 * FXML Controller class
 *
 * @author user
 */
public class CRUDCategorieController implements Initializable {

    @FXML
    private TextField tfDescription;
    @FXML
    private TableView<Catégorie> tvCategorie;
    @FXML
    private TableColumn<Catégorie, String> clDescription;
    @FXML
    private Button btAjouter;
    @FXML
    private Button btModifier;
    @FXML
    private Button btValider;
    @FXML
    private Button btSupprimer;
    
    List<Catégorie> listCategorie;
    Servicecategorie sc = new Servicecategorie();
    ObservableList<Catégorie> data;
    Catégorie categoriePourModif = null;
    @FXML
    private Button btn_back;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
         btValider.setVisible(false);
        load();
    }    

    //fonction pour chargé les donnes dans le tableu
    public void load() {
       // String query="SELECT categorie.id_catégorie,categorie.type,cour.titre,cour.fichier FROM categorie,cour WHERE categorie.cour=cour.titre";
        tvCategorie.setVisible(true);
        listCategorie = sc.afficher();
        //tableau dans javafx
        data = FXCollections.observableArrayList(); //
        if (!listCategorie.isEmpty()) {//on teste si on a des dpnnes dans la bd pour remplir le tableau dans l'interface graphoquique 
            listCategorie.stream().forEach((j) -> {
                if (j != null) {
                    //on charge les donnes 
                    data.add(new Catégorie(j.getId_catégoerie(), j.getDescription()));
                    tvCategorie.setItems(data);
                }

            });
        }
        //on affecte la colonne au tablea 
        clDescription.setCellValueFactory(new PropertyValueFactory<>("Description"));
       
    }

    
    
    
    
    
    
    @FXML
    private void AjouterCategorie(ActionEvent event) {
         //on teste si les champs de texte ne sont pas vide
        if (!"".equals(tfDescription.getText())) {
            Catégorie c = new Catégorie();
            //on prend les donnes a partire de l'intergface
            c.setDescription(tfDescription.getText());
            
            sc.ajouter(c);
            tfDescription.clear();
         
            data.add(c);
            load();
        } else {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Warning");
            alert.setHeaderText("Please Fill the Fields");
            alert.setContentText("*You Have Missed to fill some Fields");
            alert.showAndWait();
        } 
           //Image img = new Image("/checks.jpg");
         
        
        
        
    }

    @FXML
    private void ModifierCategorie(ActionEvent event) {
           categoriePourModif = tvCategorie.getSelectionModel().getSelectedItem();
        tfDescription.setText(categoriePourModif.getDescription());
        btModifier.setVisible(false);
        btValider.setVisible(true);
        
    }

    @FXML
    private void ValiderModification(ActionEvent event) {
          if (!tfDescription.getText().equals(categoriePourModif.getDescription()))
                 {

            categoriePourModif.setDescription(tfDescription.getText());
            sc.modifier(categoriePourModif);
            tfDescription.clear();
            
            load();
        }
        btModifier.setVisible(true);
        btValider.setVisible(false);
        
        
        
        
    }
    
    
    

    @FXML
    private void SupprimerCategorie(ActionEvent event) {
        
          Catégorie c = tvCategorie.getSelectionModel().getSelectedItem();
        sc.supprimer(c);
       
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmation Dialog");
        alert.setHeaderText("Look, a Confirmation Dialog");
        alert.setContentText("Are you ok with this?");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK) {
            data.clear();
            listCategorie.clear();
            load();
        } else {
            System.out.println("yessss");
        }
    }

    @FXML
    private void handleClicks(ActionEvent event) throws IOException {
          if (event.getSource() == btn_back) {
            Node node = (Node) event.getSource();

            Stage stage = (Stage) node.getScene().getWindow();
            //stage.setMaximized(true);
            stage.close();
            // hnee badll
            Scene scene = new Scene(FXMLLoader.load(getClass().getResource("/gui/CoursUI.fxml")));
            stage.setScene(scene);
            stage.show();

        }
    }
    
}
