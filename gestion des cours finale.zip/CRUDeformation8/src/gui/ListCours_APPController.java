/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import Entitie.Cour;
import Service.ServiceCour;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import javafx.application.HostServices;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author user
 */
public class ListCours_APPController implements Initializable {
   ObservableList<Cour> data;
    @FXML
    private TableView<Cour> tvCour;
    @FXML
    private TableColumn<Cour, String> clTitre;
    @FXML
    private TableColumn<Cour, String> clFichier;
    @FXML
    private TableColumn<Cour, String> clCategorie;
    @FXML
    private TextField search;
    @FXML
    private ComboBox<String> combo_formation;
        List<Cour> listCours;
    ServiceCour sc = new ServiceCour();
    @FXML
    private Button btAfficher;
private File file;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
   
    //combo_formation.setItems(sc.afficher_Formation());

         load();
         
         
         search();
    }    

    @FXML
    private void chercher(ActionEvent event) {
          ObservableList table = tvCour.getItems();
        
        search.textProperty().addListener((ObservableValue<? extends String> observable, String oldValue, String newValue) -> {
	            if (oldValue != null && (newValue.length() < oldValue.length())) {
	                tvCour.setItems(table);
	            }
	            String value = newValue.toLowerCase();
	            ObservableList<Cour> subentries = FXCollections.observableArrayList();

	            long count = tvCour.getColumns().stream().count();
	            for (int i = 0; i < tvCour.getItems().size(); i++) {
	                for (int j = 0; j < count; j++) {
	                    String entry = "" + tvCour.getColumns().get(j).getCellData(i);
	                    //if (entry.toLowerCase().equals(value)
                                    
                            if (entry.toLowerCase().contains(CharSequence.class.cast(value))) 
                            {
	                        subentries.add(tvCour.getItems().get(i));
                                
	                        break;
                            }
	                }
	            }
	            tvCour.setItems(subentries);
	        });
	        load();
    }
       private void load() {
         tvCour.setVisible(true);
        listCours = sc.afficher();
        data = FXCollections.observableArrayList();
        if (!listCours.isEmpty()) {
            listCours.stream().forEach((j) -> {
                if (j != null) {
                            data.add(new Cour(j.getID(), j.getTitre(), j.getDescription_cat(),j.getFichier()));
                    tvCour.setItems(data);
                }
            });
        }
        clTitre.setCellValueFactory(new PropertyValueFactory<>("Titre"));
        clFichier.setCellValueFactory(new PropertyValueFactory<>("Fichier"));
        
         clCategorie.setCellValueFactory(new PropertyValueFactory<>("Description_cat"));
        
        
        
        
        
        
        
        
        
        
        
//         tvCour.setVisible(true);
//        listCours = sc.afficher();
//        data = FXCollections.observableArrayList();
//        if (!listCours.isEmpty()) {
//            listCours.stream().forEach((j) -> {
//                if (j != null) {
//                    // ArrayList<Catégorie> k = s.afficher(j.getid_catégorie());
//                    data.add(new Cour(j.getID(), j.getTitre(), j.getFichier()));
//                     //   data2.add(k.getType());
//                      // tvCour.setItems(data , data2);
//                      
//                    tvCour.setItems(data);
//                }
//            });
//        }
//        clTitre.setCellValueFactory(new PropertyValueFactory<>("Titre"));
//        clFichier.setCellValueFactory(new PropertyValueFactory<>("Fichier"));
    }
       public void search() {
        search.setOnKeyReleased(e
                -> {
            if (search.getText().equals("") ) {

                try {
                    load();
                } catch (Exception ex) {
                }

            } else {

                try {
                    clTitre.setCellValueFactory(new PropertyValueFactory<>("Titre"));
        clFichier.setCellValueFactory(new PropertyValueFactory<>("Fichier"));
        
         clCategorie.setCellValueFactory(new PropertyValueFactory<>("Description_cat"));
                    tvCour.getItems().clear();

                    tvCour.setItems(sc.serach(search.getText()));

                } catch (Exception ex) {
                }
        

            }
        }
        );

    } 

    @FXML
    private void afficher(ActionEvent event) {
        
           Cour cour = tvCour.getSelectionModel().getSelectedItem();
           System.out.println(cour);
        Node node = (Node) event.getSource();

        Stage stageCourant = (Stage) node.getScene().getWindow();
        stageCourant.close();
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("detail.fxml"));
            Parent root = loader.load();
            DetailController scene2Controller = loader.getController();
            scene2Controller.initData(cour);
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.setTitle("Détail du cour");
            stage.show();
        } catch (IOException ex) {
            System.err.println(ex);
        }
       
    }

    private HostServices getHostServices() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
        
        
}
