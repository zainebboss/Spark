/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import Service.ServiceCour;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.PieChart;
import javafx.scene.control.Button;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author user
 */
public class StatCourController implements Initializable {

    @FXML
    private PieChart pie;
    @FXML
    private Button btnAjout;
    @FXML
    private Button btnListe;
    @FXML
    private Button btnstat;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       
        // TODO
         int i,j,k,f,r,h,t;
        ServiceCour a = new ServiceCour();
       i=a.CountService("php");
       k=a.CountService("java");
       f=a.CountService("sql");
       r=a.CountService("html");
       h=a.CountService("mobile");
       t=a.CountService("javafx");
       
        ObservableList<PieChart.Data> pieChartData =
               FXCollections.observableArrayList(
                       new PieChart.Data("php",i),
                       new PieChart.Data("java",k),
                       new PieChart.Data("sql",f),
                       new PieChart.Data("html",r),
                        new PieChart.Data("mobile",h),
                         new PieChart.Data("javafx",t)
                       
               );
        pie.setData(pieChartData);
        
        
        
    }  

    @FXML
    private void afficherAjouterCour(ActionEvent event) throws IOException {
          Stage primaryStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Parent root = FXMLLoader.load(getClass().getResource("CoursUI.fxml"));
        Scene scene = new Scene(root);
        primaryStage.setTitle("Ajouter Cour");
        primaryStage.setScene(scene);
        primaryStage.show();
            
    }

    @FXML
    private void afficherListerCour(ActionEvent event) throws IOException {
        Stage primaryStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Parent root = FXMLLoader.load(getClass().getResource("ListCours.fxml"));
        Scene scene = new Scene(root);
        primaryStage.setTitle("Liste des cours");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    @FXML
    private void afficherStatistiquesCours(ActionEvent event) throws IOException {
        Stage primaryStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Parent root = FXMLLoader.load(getClass().getResource("StatCour.fxml"));
        Scene scene = new Scene(root);
        primaryStage.setTitle("Stat Cour ");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    
}
