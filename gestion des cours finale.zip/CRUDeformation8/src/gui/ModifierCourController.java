/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import Entitie.Catégorie;
import Entitie.Cour;
import Service.ServiceCour;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author user
 */
public class ModifierCourController implements Initializable {

    @FXML
    private Button btAjouter;
    @FXML
    private Button btnAnnuler;
    @FXML
    private TextField tfFichier;
    @FXML
    private TextField tfTitre;
    @FXML
    private Button btnAjout;
    @FXML
    private Button btnListe;
    @FXML
    private Button btnstat;

    private Cour cour = new Cour();
    ServiceCour sc = new ServiceCour();

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

    }

    public void initData(Cour recievedCour) {
        System.out.println("cour : " + recievedCour);
        if (recievedCour != null) {
            this.cour.setID(recievedCour.getID());
            this.cour.setFichier(recievedCour.getFichier());
            this.cour.setTitre(recievedCour.getTitre());
            tfTitre.setText(recievedCour.getTitre());
            
            tfFichier.setText(recievedCour.getFichier());
        }

    }
    @FXML
    private void enregistrer(ActionEvent event) throws IOException {

       this.cour.setFichier(tfFichier.getText());
        this.cour.setTitre(tfTitre.getText());
        System.out.println("updatedCour:" + this.cour);
        sc.modifier(this.cour);
        tfTitre.clear();
        tfFichier.clear();

        Node node = (Node) event.getSource();

        Stage stageCourant = (Stage) node.getScene().getWindow();
        stageCourant.close();

        Stage primaryStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Parent root = FXMLLoader.load(getClass().getResource("ListCours.fxml"));
        Scene scene = new Scene(root);
        primaryStage.setTitle("Liste des Cours");
        primaryStage.setScene(scene);
        primaryStage.show();

    }

    @FXML
    private void annuler(ActionEvent event) {
    }

    @FXML
    private void afficherAjouterCours(ActionEvent event) throws IOException {
          Stage primaryStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Parent root = FXMLLoader.load(getClass().getResource("CoursUI.fxml"));
        Scene scene = new Scene(root);
        primaryStage.setTitle("Ajouter Cour");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    @FXML
    private void afficherListerCours(ActionEvent event) throws IOException {
        Stage primaryStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Parent root = FXMLLoader.load(getClass().getResource("ListCours.fxml"));
        Scene scene = new Scene(root);
        primaryStage.setTitle("Liste des cours");
        primaryStage.setScene(scene);
        primaryStage.show();     
    }

    @FXML
    private void afficherStatistiquesCours(ActionEvent event) {
    }

    public void setCour(Cour cour) {
        this.cour = cour;
    }

    void initData(Catégorie Categorie) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
