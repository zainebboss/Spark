/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import Entitie.Catégorie;
import Entitie.Cour;
import Entitie.Formation;
import Service.ServiceCour;
import Service.Servicecategorie;
import Utils.Connexion;
import java.awt.Desktop;
import java.io.File;


import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.text.Font;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.stage.Stage;
import javafx.util.Duration;
import org.controlsfx.control.Notifications;

/**
 * FXML Controller class
 *
 * @author user
 */
public class CoursUIController implements Initializable {

    @FXML
    private TextField tfTitre;
    @FXML
    private TextField tfFichier;
    @FXML
    private Button btAjouter;
    ServiceCour sc = new ServiceCour();
    @FXML
    private Button btnAnnuler;
    @FXML
    private Button btnAjout;
    @FXML
    private Button btnListe;
    @FXML
    private Button btnstat;
    @FXML
    private ComboBox<String> form;
    private Connection con;
    ObservableList <String> f1 = FXCollections.observableArrayList();

    @FXML
    private Button browse;
    private int selectFormation;
    
    private File file;
    private PreparedStatement stat;
    private ResultSet rs;
    @FXML
    private ComboBox<String> combo_categorie;
    Servicecategorie SV_Categorie = new Servicecategorie();    
    @FXML
    private Button btn_categorie;
/**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
            combo_categorie.setItems(SV_Categorie.afficher_Categorie());
            combo_categorie.getSelectionModel().select(0);
        UpdateComboBox();
    }
 Image img = new Image("/checks.jpg");
 
    @FXML
    public void enregistrer(ActionEvent event) {
  
         
         
        if (!"".equals(tfTitre.getText()) && !"".equals(tfFichier.getText())) {
            Cour c = new Cour();
            getbyIdFormation();
            c.setTitre(tfTitre.getText());
            c.setFichier(tfFichier.getText());
            c.setFormation_id(selectFormation);
            c.setDescription_cat(combo_categorie.getSelectionModel().getSelectedItem());
            //c.setid_catégorie(Integer.parseInt(tfCategorie.getText()));
            
            sc.ajouter(c);
                   Notifications notificationBuilder = Notifications.create()
                 
                                                     .title("cour ajouté")
                                                     .text("ajout avec succés")
                                            
                                                     .graphic(new ImageView(img))
                                                     .hideAfter(javafx.util.Duration.seconds(2) )
                                                      .position(Pos.TOP_LEFT) ;
         notificationBuilder.show();
        
            tfTitre.clear();
            tfFichier.clear();
//            data.add(c);
//            load();
        } else {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Warning");
            alert.setHeaderText("Please Fill the Fields");
            alert.setContentText("*You Have Missed to fill some Fields");
            alert.showAndWait();
        }
    
    }
    
    public void UpdateComboBox(){
        
        
        try {
            con = Connexion.getInstance().getConnection();
            String requete = "SELECT * FROM formation order by id desc";
            PreparedStatement pst = con.prepareStatement(requete);
            ResultSet rs = pst.executeQuery();
            
            while (rs.next()) {
               
            f1.add(rs.getString("titre")); 
            
            }
       form.setItems(f1);
            
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }


    @FXML
    private void Browse(ActionEvent event) throws SQLException   {
         stat=con.prepareStatement("INSERT INTO cour(titre,fichier) VALUES (?,?)");
         FileChooser fc = new FileChooser();
         File selectedFile = fc.showOpenDialog(null);
         if(selectedFile != null){
             tfFichier.appendText(selectedFile.getAbsolutePath());
            // Image image =new Image(file.toURI().toString(),80 ,80, true,true);
             //tfFichier.setText(selectedFile.getName());
           // tfFichier.getText().add(selectedFile.getName());
             
         }else {
             System.out.print("FILE IS NOT VALID");
         }
        
         
        
         
         
         
//         filechooser.getExtensionFilters().addAll(
//               new ExtensionFilter("All Files", "*txt"),
//                 new ExtensionFilter("Text Files", "*")
//                 
//         );
//         browse=new Button("Browse");
//         browse.setFont(Font.font("senserif" , 15));
//         browse.setOnAction(e-> {
//                 file = filechooser.showOpenDialog(null);
//                 if(file!=null){
//                     try {
//                         desktop.open(file);
//                     } catch (IOException ex) {
//                         Logger.getLogger(CoursUIController.class.getName()).log(Level.SEVERE, null, ex);
//                     }
//                 }
                     
         }
        
        
    
    
    
    
    

    @FXML
    public void annuler(ActionEvent event) {
         
          
    }

    @FXML
    public void afficherAjouterCours(ActionEvent event) {
        System.out.println("ajouter");
       
    }

    @FXML
    public void afficherListerCours(ActionEvent event) throws IOException {
        Stage primaryStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Parent root = FXMLLoader.load(getClass().getResource("ListCours.fxml"));
        Scene scene = new Scene(root);
        primaryStage.setTitle("Liste des Cours");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    @FXML
    public void afficherStatistiquesCours(ActionEvent event) throws IOException {
        Stage primaryStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Parent root = FXMLLoader.load(getClass().getResource("StatCour.fxml"));
        Scene scene = new Scene(root);
        primaryStage.setTitle("Stat Cour ");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    
    private void getbyIdFormation() {
        
        String s = form.getSelectionModel().getSelectedItem();
            try {
                 String req = "SELECT * FROM formation WHERE titre=?";
            stat = con.prepareStatement(req);
                stat.setString(1, s);
                rs = stat.executeQuery();
             while (rs.next()) {
            selectFormation=rs.getInt("id");
             }
            } catch (SQLException ex) {
                Logger.getLogger(CoursUIController.class.getName()).log(Level.SEVERE, null, ex);
            }
            }

    @FXML
    private void handleClicks(ActionEvent event) throws IOException {
          if (event.getSource() == btn_categorie) {
            
            Node node = (Node) event.getSource();

            Stage stage = (Stage) node.getScene().getWindow();
            //stage.setMaximized(true);
            stage.close();
            // hnee badll
            Scene scene = new Scene(FXMLLoader.load(getClass().getResource("/gui/CRUDCategorie.fxml")));
            stage.setScene(scene);
            stage.show();

        }
    }
    
    
    
    
    
    
    
}
