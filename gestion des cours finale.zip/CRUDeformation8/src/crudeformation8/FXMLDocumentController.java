/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package crudeformation8;

import Entitie.Catégorie;
import Entitie.Cour;
import Service.ServiceCour;
import java.net.URL;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 *
 * @author user
 */
public class FXMLDocumentController implements Initializable {

    private TextField tfTitre;
    private TextField tfFichier;
    private TableView<Cour> tvCour;
    private TableColumn<Cour, String> clTitre;
    private TableColumn<Cour, String> clFichier;
    @FXML
    private Button btAjouter;
    @FXML
    private Button btModifier;
    @FXML
    private Button btSupprimer;
    @FXML
    private Button btValider;

    List<Cour> listCours;
    ServiceCour sc = new ServiceCour();
    ObservableList<Cour> data;
    Cour coursPourModif = null;
//    @FXML
//    private TextField tfType;
//    @FXML
//    private TableView<Catégorie> tvCategorie;
//    @FXML
//    private TableColumn<Catégorie, String> clType;

    private void handleButtonAction(ActionEvent event) {

    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        btValider.setVisible(false);
        load();
    }


    //fonction pour chargé les donnes dans le tableu
    public void load() {
        tvCour.setVisible(true);
        listCours = sc.afficher();
        //tableau dans javafx
        data = FXCollections.observableArrayList(); //
        if (!listCours.isEmpty()) {//on teste si on a des dpnnes dans la bd pour remplir le tableau dans l'interface graphoquique 
            listCours.stream().forEach((j) -> {
                if (j != null) {
                    //on charge les donnes 
                    data.add(new Cour(j.getID(), j.getTitre(), j.getFichier()));
                    tvCour.setItems(data);
                }

            });
        }
        //on affecte la colonne au tablea 
        clTitre.setCellValueFactory(new PropertyValueFactory<>("Titre"));
        clFichier.setCellValueFactory(new PropertyValueFactory<>("Fichier"));
    }

    private void AjouterCour(ActionEvent event) {
        //on teste si les champs de texte ne sont pas vide
        if (!"".equals(tfTitre.getText()) && !"".equals(tfFichier.getText())) {
            Cour c = new Cour();
            //on prend les donnes a partire de l'intergface
            c.setTitre(tfTitre.getText());
           // c.setFichier(tfFichier.getText());
            sc.ajouter(c);
            tfTitre.clear();
            tfFichier.clear();
            data.add(c);
            load();
        } else {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Warning");
            alert.setHeaderText("Please Fill the Fields");
            alert.setContentText("*You Have Missed to fill some Fields");
            alert.showAndWait();
        }
    }

    private void ModifierCour(ActionEvent event) {
        coursPourModif = tvCour.getSelectionModel().getSelectedItem();
        tfTitre.setText(coursPourModif.getTitre());
       // tfFichier.setText(coursPourModif.getFichier());
        btModifier.setVisible(false);
        btValider.setVisible(true);
    }

    @FXML
    private void ValiderModification(ActionEvent event) {

        if (!tfTitre.getText().equals(coursPourModif.getTitre())
                || !tfFichier.getText().equals(coursPourModif.getFichier())) {

            coursPourModif.setTitre(tfTitre.getText());
           // coursPourModif.setFichier(tfFichier.getText());
            sc.modifier(coursPourModif);
            tfTitre.clear();
            tfFichier.clear();
            load();
        }
        btModifier.setVisible(true);
        btValider.setVisible(false);

    }

    private void SupprimerCour(ActionEvent event) {
        Cour c = tvCour.getSelectionModel().getSelectedItem();
        sc.supprimer(c);
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmation Dialog");
        alert.setHeaderText("Look, a Confirmation Dialog");
        alert.setContentText("Are you ok with this?");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK) {
            data.clear();
            listCours.clear();
            load();
        } else {
            System.out.println("yessss");
        }

    }

    @FXML
    private void AjouterCategorie(ActionEvent event) {
    }

    @FXML
    private void ModifierCategorie(ActionEvent event) {
    }

    @FXML
    private void SupprimerCategorie(ActionEvent event) {
    }

}
