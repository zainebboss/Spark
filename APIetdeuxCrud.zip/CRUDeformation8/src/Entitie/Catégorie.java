/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entitie;

/**
 *
 * @author user
 */
public class Catégorie {
    int id_catégoerie;
    String type;
    Cour cour;

    public Catégorie(int id_catégoerie, String type) {
        this.id_catégoerie = id_catégoerie;
        this.type = type;
    }

    public Catégorie() {
       
    }

    public int getId_catégoerie() {
        return id_catégoerie;
    }

    public String getType() {
        return type;
    }

    public void setId_catégoerie(int id_catégoerie) {
        this.id_catégoerie = id_catégoerie;
    }

    public void setType(String type) {
        this.type = type;
    }
    
    
     @Override
    public String toString() {
        return "Catégorie{" + "id_catégorie=" + id_catégoerie + ", type=" + type +  '}';
    }
}
