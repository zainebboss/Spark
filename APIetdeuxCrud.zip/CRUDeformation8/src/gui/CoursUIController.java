/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import Entitie.Cour;
import Service.ServiceCour;


import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.util.Duration;
import org.controlsfx.control.Notifications;

/**
 * FXML Controller class
 *
 * @author user
 */
public class CoursUIController implements Initializable {

    @FXML
    private TextField tfTitre;
    @FXML
    private TextField tfFichier;
    @FXML
    private Button btAjouter;
    ServiceCour sc = new ServiceCour();
    @FXML
    private Button btnAnnuler;
    @FXML
    private Button btnAjout;
    @FXML
    private Button btnListe;
    @FXML
    private Button btnstat;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }
 Image img = new Image("/checks.jpg");
    @FXML
    public void enregistrer(ActionEvent event) {
         Notifications notificationBuilder = Notifications.create()
                 
                                                     .title("cour ajouté")
                                                     .text("ajout avec succés")
                                            
                                                     .graphic(new ImageView(img))
                                                     .hideAfter(javafx.util.Duration.seconds(2) )
                                                      .position(Pos.TOP_LEFT) ;
         notificationBuilder.show();
        if (!"".equals(tfTitre.getText()) && !"".equals(tfFichier.getText())) {
            Cour c = new Cour();
            c.setTitre(tfTitre.getText());
            c.setFichier(tfFichier.getText());
            //c.setid_catégorie(Integer.parseInt(tfCategorie.getText()));
            
            sc.ajouter(c);
            tfTitre.clear();
            tfFichier.clear();
//            data.add(c);
//            load();
        } else {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Warning");
            alert.setHeaderText("Please Fill the Fields");
            alert.setContentText("*You Have Missed to fill some Fields");
            alert.showAndWait();
        }
    
    }

    @FXML
    public void annuler(ActionEvent event) {
         
          
    }

    @FXML
    public void afficherAjouterCours(ActionEvent event) {
        System.out.println("ajouter");
       
    }

    @FXML
    public void afficherListerCours(ActionEvent event) throws IOException {
        Stage primaryStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Parent root = FXMLLoader.load(getClass().getResource("ListCours.fxml"));
        Scene scene = new Scene(root);
        primaryStage.setTitle("Liste des Cours");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    @FXML
    public void afficherStatistiquesCours(ActionEvent event) throws IOException {
        Stage primaryStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Parent root = FXMLLoader.load(getClass().getResource("StatCour.fxml"));
        Scene scene = new Scene(root);
        primaryStage.setTitle("Stat Cour ");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}
